const ytdl = require('ytdl-core');
const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');

async function downloadYouTubeMedia(url, type = 'mp3') {
  const id = new Date().getTime();
  const output = path.join(__dirname, `${id}.${type}`);

  return new Promise((resolve, reject) => {
    const stream = ytdl(url, { quality: type === 'mp3' ? 'highestaudio' : 'highestvideo' });

    if (type === 'mp3') {
      ffmpeg(stream)
        .audioBitrate(128)
        .format('mp3')
        .save(output)
        .on('end', () => resolve(output))
        .on('error', reject);
    } else {
      stream.pipe(fs.createWriteStream(output))
        .on('finish', () => resolve(output))
        .on('error', reject);
    }
  });
}

module.exports = { downloadYouTubeMedia };