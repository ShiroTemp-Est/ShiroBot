const { default: makeWASocket, useSingleFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const axios = require('axios');
const { downloadYouTubeMedia } = require('./download');

const { state, saveState } = useSingleFileAuthState('./auth.json');

async function startBot() {
  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true,
  });

  sock.ev.on('creds.update', saveState);

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
      const shouldReconnect = (lastDisconnect?.error instanceof Boom)
        ? lastDisconnect.error.output.statusCode !== DisconnectReason.loggedOut
        : true;
      if (shouldReconnect) startBot();
    } else if (connection === 'open') {
      console.log('🤖 Bot conectado a WhatsApp');
    }
  });

  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text;

    if (!text) return;

    if (text === '!menu') {
      const menu = `🧠 *Bot de WhatsApp* por *ShiroTempest*
      
📌 *Comandos disponibles:*
• !menu - Muestra este menú
• !ytmp3 [URL] - Descarga audio de YouTube
• !ytmp4 [URL] - Descarga video de YouTube
• ¡Escríbeme algo y te respondo como SimSimi!

🌐 Disfruta del poder de la automatización 🚀`;

      return sock.sendMessage(from, { text: menu });
    }

    if (text.startsWith('!ytmp3')) {
      const url = text.split(' ')[1];
      if (!url) return sock.sendMessage(from, { text: 'Envía un enlace de YouTube.' });

      const file = await downloadYouTubeMedia(url, 'mp3');
      await sock.sendMessage(from, { audio: { url: file }, mimetype: 'audio/mp4' });
      fs.unlinkSync(file);
    } else if (text.startsWith('!ytmp4')) {
      const url = text.split(' ')[1];
      if (!url) return sock.sendMessage(from, { text: 'Envía un enlace de YouTube.' });

      const file = await downloadYouTubeMedia(url, 'mp4');
      await sock.sendMessage(from, { video: { url: file }, caption: 'Aquí tienes tu video' });
      fs.unlinkSync(file);
    } else {
      // Respuesta tipo SimSimi (simulada localmente con IA básica)
      const response = await getSimpleAIResponse(text);
      await sock.sendMessage(from, { text: response });
    }
  });
}

async function getSimpleAIResponse(input) {
  try {
    // Simulación simple tipo SimSimi (puede conectarse a alguna API si se desea)
    const keywords = {
      hola: "¡Hola! ¿Cómo estás?",
      adiós: "¡Hasta luego!",
      gracias: "¡De nada!",
      nombre: "Me llamo TempestBot, creado por ShiroTempest.",
    };

    const key = Object.keys(keywords).find(k => input.toLowerCase().includes(k));
    return key ? keywords[key] : "¡Interesante! Cuéntame más 👀";
  } catch (err) {
    return "Ups, hubo un error al intentar responder.";
  }
}

startBot();