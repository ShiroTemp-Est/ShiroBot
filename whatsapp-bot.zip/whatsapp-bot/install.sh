#!/bin/bash
echo "📦 Instalando dependencias..."
pkg update && pkg upgrade -y
pkg install nodejs ffmpeg git wget curl -y

echo "📁 Configurando proyecto..."
npm install @whiskeysockets/baileys ytdl-core fluent-ffmpeg axios

echo "✅ Instalación completa. Ejecuta el bot con: node index.js"